<?php echo e($slot); ?>

<?php /**PATH D:\belibareng\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>